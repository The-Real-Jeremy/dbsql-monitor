app_name = "dbsql-monitor"
app_module = "dbsql_monitor.backend.app:app"
app_slug = "dbsql_monitor"
api_prefix = "/api"